extends Area2D

@export var flap_power:float = 1
@export var grav:float = 5
@export var rotationspeed:float = 5
var velocity:float = 0

signal death

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.y = position.y + velocity
	
	velocity += grav * delta
	
	
	if Input.is_action_just_pressed("flap"):
		velocity = -flap_power
	if velocity >= 0:
		rotation += deg_to_rad(rotationspeed)
		$AnimatedSprite2D.play("idle");
	elif velocity < 0:
		rotation -= deg_to_rad(rotationspeed)
		$AnimatedSprite2D.play("fly")
	else: return
	
	rotation = clamp(rotation, deg_to_rad(-30), deg_to_rad(30))
	
	
	   
	
	


func _on_area_entered(area: Area2D) -> void:
	if area.name == "UpperPipe":
		emit_signal("death")
		grav = 200
		print("death");
	if area.name == "LowerPipe":
		emit_signal("death")
		grav = 200
		print("death");
