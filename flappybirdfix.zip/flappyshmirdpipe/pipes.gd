extends Node2D

var scroll_speed:int = 5
@onready var screenwidth:float = get_window().size.x
var has_scored:boolean = false

signal getpoint

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x -= scroll_speed

	if position.x <= 100 and has_scored == false:
		emit_signal("getpoint")
		has_scored = true

	if position.x <= -screenwidth:
		queue_free()
