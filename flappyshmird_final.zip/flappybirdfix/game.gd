extends Node2D

@export var scroll_speed:float = 4
@onready var screenwidth:float = get_window().size.x
@onready var pipes = preload("res://pipes.tscn")

var score:int = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$bg1.position = Vector2(0,0)
	$bg2.position = Vector2(screenwidth, 0)
	$Timer.start(3)
	$Label.text = "my score is " + str(score)
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$bg1.position.x = $bg1.position.x - scroll_speed
	$bg2.position.x = $bg2.position.x - scroll_speed
	if $bg1.position.x <= -screenwidth:
		$bg1.position.x = screenwidth;
	if $bg2.position.x <= -screenwidth:
		$bg2.position.x = screenwidth;
	#if $Bird collision == $Pipes:

func create_pipes() -> void:
	var new_pipes = pipes.instantiate()
	add_child(new_pipes)
	move_child(new_pipes, 3)
	new_pipes.position.x = screenwidth + 35
	new_pipes.getpoint.connect(add_points)


func _on_timer_timeout() -> void:
	create_pipes()
	$Timer.start(3)



func _on_bird_death() -> void:
	pass

func add_points() -> void:
	score += 1
	$Label.text = "my score is " + str(score)
