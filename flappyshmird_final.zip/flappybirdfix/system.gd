extends Node2D

@onready var game = preload("res://game.tscn")
@onready var menu = preload("res://menu.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("Escape"):
		get_tree().change_scene_to_file("res://system.tscn")


func _on_menu_quit_game() -> void:
	get_tree().quit()


func _on_menu_start_game() -> void:
	var startgame = game.instantiate()
	add_child(startgame)
	remove_child($menu)
	
	
	


	
